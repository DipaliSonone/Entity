package com.example.OMS.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Time;
import java.util.Date;

@Entity
@Table(name = "Attendence")
@Getter
@Setter
public class Attendence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int attendenceId;
    private Date date;
    private Time hours;
    private Time inTime;
    private Time outTime;
    private String name;
    private Integer userId;
    private Boolean status;


}
