package com.example.OMS.Dto;

public class TasksDto {

    private int taskId;
    private String description;
    private String assignedTo;
    private String taskName;
    private boolean status;
    private boolean duration;

}
