package com.example.OMS.Entity;


import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "LeaveManagement")
public class LeaveManagement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int leaveManagementId;
    private int userId;
    private Date date;
    private String reason;
    private String leaveType;
    private Boolean status;
    private String approvedby;
}
