package com.example.OMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
